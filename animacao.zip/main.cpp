// rvencio Ago/2022
/* 
    g++ main.cpp Inicializar.cpp Desenhar*.cpp -o vai -lglut -lGL -lGLEW -lGLU  
    ./vai &
*/

#include <iostream>
#include <GL/glut.h>
#include <math.h>

# include "Inicializar.h"
# include "Desenhar.h"

int main(int argc, char** argv){
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_DEPTH | GLUT_RGBA);
	glutInitWindowSize(500, 500);
	glutInitWindowPosition(10, 10);
	glutCreateWindow("Hell on World");
	Inicializar();
	glutDisplayFunc(DesenharHelloWorld);
//	glutDisplayFunc(DesenharMinas);
//    	glutDisplayFunc(DesenharJapao);
	glutMainLoop();
	return 0;
}

