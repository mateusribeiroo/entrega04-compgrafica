void DesenharHelloWorld(void);
void DesenharJapao(void);
void DesenharMinas(void);
