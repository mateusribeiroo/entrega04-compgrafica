void Inicializar(void);
